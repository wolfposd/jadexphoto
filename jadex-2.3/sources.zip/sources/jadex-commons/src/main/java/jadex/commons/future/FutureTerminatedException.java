package jadex.commons.future;

/**
 * 
 */
public class FutureTerminatedException extends RuntimeException
{
}
