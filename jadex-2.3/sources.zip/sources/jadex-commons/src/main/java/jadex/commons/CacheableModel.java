package jadex.commons;

public class CacheableModel
{

}
