
package jadex.xml.tutorial.jibx.example17;

public class Identity {
    public int customerNumber;
}
