
package jadex.xml.tutorial.jibx.example16;

public class Identity 
{
    public int customerNumber;
}
