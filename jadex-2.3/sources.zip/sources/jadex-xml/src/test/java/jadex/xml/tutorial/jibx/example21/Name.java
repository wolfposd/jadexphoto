
package jadex.xml.tutorial.jibx.example21;

public class Name {
    public String firstName;
    public String lastName;
}
