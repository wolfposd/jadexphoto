
package jadex.xml.tutorial.jibx.example03;

public class Person {
    public String firstName;
    public String lastName;
    public int customerNumber;
}
